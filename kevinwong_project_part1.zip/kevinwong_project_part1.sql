/*	Final Project Part 1
	Kevin Wong 
	CS150A Fall 2021 */
    
CREATE DATABASE university;
USE university;

-- dropping tables if they exist
DROP TABLE IF EXISTS academic_session;
DROP TABLE IF EXISTS department;
DROP TABLE IF EXISTS parent_info;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS course;
DROP TABLE IF EXISTS faculty;
DROP TABLE IF EXISTS exam_type;
DROP TABLE IF EXISTS exam;
DROP TABLE IF EXISTS exam_result;
DROP TABLE IF EXISTS student_att;
DROP TABLE IF EXISTS student_course;
DROP TABLE IF EXISTS faculty_course;
DROP TABLE IF EXISTS faculty_login;

-- creating academic table 
CREATE TABLE academic_session(
	session_id INT NOT NULL, 
    session_name VARCHAR(25),
    CONSTRAINT session_id_pk PRIMARY KEY (session_id),
    CONSTRAINT UNIQUE (session_name)
);

-- creating department table
CREATE TABLE department(
	dept_id INT NOT NULL, 
    dept_name VARCHAR(25), 
    head VARCHAR(25),
    CONSTRAINT dept_id_pk PRIMARY KEY (dept_id),
    CONSTRAINT UNIQUE (dept_name)
);

-- creating parent_info table
CREATE TABLE parent_info(
	parent_id INT NOT NULL, 
    parent1_fn VARCHAR(25), 
    parent1_ln VARCHAR(25), 
    parent2_fn VARCHAR(25), 
    parent2_ln VARCHAR(25),
    CONSTRAINT parent_id_pk PRIMARY KEY (parent_id)
);

-- creating table student
CREATE TABLE student(
	student_id INT NOT NULL, 
	first_name VARCHAR(25), 
	last_name VARCHAR(25), 
	reg_year DATE, 
	email VARCHAR(35), 
	parent_id INT,
    CONSTRAINT student_id_pk PRIMARY KEY (student_id),
    CONSTRAINT student_parent_info_fk FOREIGN KEY (parent_id)
		REFERENCES parent_info (parent_id),
    CONSTRAINT UNIQUE (email)
);

-- creating table course
CREATE TABLE course(
	course_id INT NOT NULL, 
    course_name VARCHAR(48),   
    session_id INT,  
    dept_id INT, 
    logon_id VARCHAR(10), 
    password VARCHAR(25), 
    building VARCHAR(10), 
    room INT, 
    date_time VARCHAR(10),
    CONSTRAINT course_id_pk PRIMARY KEY (course_id),
    CONSTRAINT course_academic_session_fk FOREIGN KEY (session_id)
		REFERENCES academic_session (session_id),
	CONSTRAINT course_department_fk FOREIGN KEY (dept_id )
		REFERENCES department (dept_id),
    CONSTRAINT UNIQUE (course_name)
); 

-- creating table faculty
CREATE TABLE faculty(
	faculty_id INT NOT NULL, 
    first_name VARCHAR(25), 
    last_name VARCHAR(25), 
    faculty_email VARCHAR(25), 
    salary INT, 
    insurance VARCHAR(25),
    hourly_rate INT, 
    dept_id INT,
    CONSTRAINT faculty_id_pk PRIMARY KEY (faculty_id),
    CONSTRAINT faculty_department_fk FOREIGN KEY (dept_id)
		REFERENCES department (dept_id),
    CONSTRAINT UNIQUE (faculty_email)
); 

-- creating table exam
CREATE TABLE exam( 
	exam_id INT NOT NULL, 
    start_date DATE, 
    exam_type VARCHAR(10),
    course_id INT,
    CONSTRAINT exam_course_id_pk PRIMARY KEY (exam_id, course_id),
	CONSTRAINT exam_course_fk FOREIGN KEY (course_id)
		REFERENCES course (course_id),
	CONSTRAINT UNIQUE (exam_type)
); 

-- creating table exam_type 
CREATE TABLE exam_type(
	exam_type VARCHAR(10), 
	name VARCHAR(25), 
    description VARCHAR(48),
    CONSTRAINT exam_type_pk PRIMARY KEY (exam_type),
	CONSTRAINT exam_type_exam_fk FOREIGN KEY (exam_type)
		REFERENCES exam (exam_type)
); 

-- creating table exam_result
CREATE TABLE exam_result( 
	student_id INT NOT NULL, 
    course_id INT NOT NULL, 
    exam_id INT NOT NULL, 
    exam_grade INT,
    CONSTRAINT stu_crs_ex_pk PRIMARY KEY (student_id, course_id, exam_id),
	CONSTRAINT exam_result_student_fk FOREIGN KEY (student_id)
		REFERENCES student (student_id),
	CONSTRAINT exam_result_exam_fk FOREIGN KEY (exam_id)
		REFERENCES exam (exam_id)
); 

-- creating table student_att
CREATE TABLE student_att(
	student_id INT NOT NULL, 
    session_id INT NOT NULL, 
    num_work_days INT, 
    num_days_off INT, 
    exam_eligibility VARCHAR(5),
    CONSTRAINT stu_ses_pk PRIMARY KEY (student_id, session_id),
    CONSTRAINT student_att_student_fk FOREIGN KEY (student_id)
		REFERENCES student (student_id),
	CONSTRAINT student_att_academic_session_fk FOREIGN KEY (session_id)
		REFERENCES academic_session (session_id)
);

-- creating table student_course
CREATE TABLE student_course(
	student_id INT NOT NULL, 
    course_id INT NOT NULL, 
    grade CHAR(2),
    CONSTRAINT stu_crs_pk PRIMARY KEY (student_id, course_id),
	CONSTRAINT student_course_student_fk FOREIGN KEY (student_id)
		REFERENCES student (student_id),
	CONSTRAINT student_course_course_fk FOREIGN KEY (course_id)
		REFERENCES course (course_id)
);

-- creating table faculty_course
CREATE TABLE faculty_course( 
	faculty_id INT NOT NULL, 
    course_id INT NOT NULL, 
    contact_hrs VARCHAR(10),
    CONSTRAINT fac_crs_pk PRIMARY KEY (faculty_id, course_id),
	CONSTRAINT faculty_course_faculty_fk FOREIGN KEY (faculty_id)
		REFERENCES faculty (faculty_id),
	CONSTRAINT faculty_course_course_fk FOREIGN KEY (course_id)
		REFERENCES course (course_id)
);

-- creating table faculty_login
CREATE TABLE faculty_login(
	faculty_id INT NOT NULL, 
    login_date_time DATETIME NOT NULL DEFAULT '2017-06-01 00:00:00',
    CONSTRAINT fac_log_pk PRIMARY KEY (faculty_id, login_date_time),
	CONSTRAINT faculty_login_faculty_fk FOREIGN KEY (faculty_id)
		REFERENCES faculty (faculty_id)
);

DESCRIBE academic_session;
DESCRIBE department;
DESCRIBE parent_info;
DESCRIBE student;
DESCRIBE course;
DESCRIBE faculty;
DESCRIBE exam_type;
DESCRIBE exam;
DESCRIBE exam_result;
DESCRIBE student_att;
DESCRIBE student_course;
DESCRIBE faculty_course;
DESCRIBE faculty_login;