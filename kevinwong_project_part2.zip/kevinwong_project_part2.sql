/*	Final Project Part 2
	Kevin Wong 
	CS150A Fall 2021 */
    
USE university;

-- 1. Display the data inserted in the tables created for the University database.
SELECT *
FROM academic_session;
SELECT * 
FROM course;
SELECT * 
FROM department;
SELECT * 
FROM exam;
SELECT * 
FROM exam_result;
SELECT * 
FROM exam_type;
SELECT * 
FROM faculty;
SELECT * 
FROM faculty_course;
SELECT *
FROM faculty_login;
SELECT *
FROM parent_info;
SELECT *
FROM student;
SELECT * 
FROM student_att;
SELECT * 
FROM student_course;

-- 2. Display the different courses offered by the departments in the school. 
SELECT 	course_id,
		course_name,
		dept_name
FROM course
JOIN department
	ON course.dept_id = department.dept_id
;

-- 3. Display the courses offered in the Fall session. 
SELECT 	course.course_name,
		academic_session.session_name
FROM course
JOIN academic_session
	ON course.session_id = academic_session.session_id
WHERE academic_session.session_name = 'fall session'
;

-- 4. Display the course details, the department that offers the courses and students who have enrolled for those courses.
SELECT 	course.course_name,
		student_course.student_id,
		department.dept_name
FROM course
JOIN department 
	ON course.dept_id = department.dept_id
JOIN student_course
	ON course.course_id = student_course.course_id
;

-- 5. Display the names of the courses, the department that offers those courses, and students who have enrolled for those courses for department 20.
SELECT 	course.course_name,
		student_course.student_id,
		department.dept_name
FROM course
JOIN department 
	ON course.dept_id = department.dept_id
JOIN student_course
	ON course.course_id = student_course.course_id
WHERE department.dept_id = 20
;

-- 6. Display the details of the exam grades obtained by students who have opted for the course with ID in the range of 190 to 192.
SELECT 	course.course_id,
		course.course_name,
		exam_result.exam_grade,
        exam_result.exam_id
FROM course
JOIN exam_result
	ON course.course_id = exam_result.course_id
WHERE course.course_id BETWEEN 190 AND 192
ORDER BY course.course_id
;

-- 7. Retrieve the rows from the EXAM_RESULT table, even if there are no matching records in the COURSE table.
SELECT 	er.student_id,
		er.exam_grade,
		course.course_id,
        course.course_name
FROM exam_result AS er
LEFT JOIN course
	ON er.course_id = course.course_id
;

-- 8. Retrieve the exam grade obtained by each student for every exam attempted.
SELECT 	CONCAT(student.first_name," ", student.last_name) AS 'student name',
		student.student_id,
		er.exam_grade
FROM student
JOIN exam_result AS er
	ON student.student_id = er.student_id
;

-- 9. Write a query to check if a student is eligible to take exams based on the number of class days attended.
SELECT 	student_id,
		num_work_days,
		exam_eligibility
FROM student_att
;

-- 10. The faculty of the different Departments realized that the exam grades entered in the EXAM_RESULT were showing an increased value of 5 points for each entry. Can you display the exam grades with 5 points subtracted from the marks obtained by each student?
SELECT 	CONCAT(student.first_name," ", student.last_name) AS 'student name',
		student.student_id,
        er.exam_grade AS 'original exam grade',
		er.exam_grade - 5 AS 'adjusted exam grade'
FROM student
JOIN exam_result AS er
	ON student.student_id = er.student_id
;